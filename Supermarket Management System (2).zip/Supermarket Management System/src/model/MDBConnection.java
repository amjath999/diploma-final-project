
package model;

import java.sql.*;

public class MDBConnection {
    
  private static Connection con;
    public static Connection createConnection()
    {
        try
        {
             String dbpath = "jdbc:mysql://localhost:3308/Supermart_Management_System"; 
              con = DriverManager.getConnection(dbpath,"root","");
        }
        catch(SQLException e)
        {
            System.err.println(e.getMessage());
        }
       return con;
    }

    
}
