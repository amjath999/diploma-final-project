
package model;

import com.mysql.cj.jdbc.result.ResultSetMetaData;
import com.toedter.calendar.JDateChooser;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Date;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;


public class MSearch_Item {
    
      
    public void searchItem(int itemId, JTextArea textArea) {
        try (Connection con = MDBConnection.createConnection();
                Statement st = con.createStatement();
                ResultSet rst = st.executeQuery("select * from itemdetail where itemId = '" + itemId + "'")) {
            if (rst.next()) {
                StringBuilder itemDetails = new StringBuilder();
                 itemDetails.append("Item ID: ").append(rst.getString("itemId")).append("\n");
            itemDetails.append("Item Name: ").append(rst.getString("itemName")).append("\n");
            itemDetails.append("Item Description: ").append(rst.getString("itemDescription")).append("\n");
            itemDetails.append("Quantity: ").append(rst.getString("quantity")).append("\n");
            itemDetails.append("Unit Price: ").append(rst.getString("unitPrice")).append("\n");
            itemDetails.append("Item Type: ").append(rst.getString("itemType")).append("\n");
                
                textArea.setText(itemDetails.toString());
            } else {
                JOptionPane.showMessageDialog(null, "Item not found", "Error", JOptionPane.ERROR_MESSAGE);
                textArea.setText("Item not found.");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            textArea.setText("Error: " + e.getMessage());
        }
    }
       
 
   
}

    

