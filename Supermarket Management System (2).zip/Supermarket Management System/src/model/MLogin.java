package model;

import java.sql.*;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class MLogin {

    public User login(String userType, String username, String password) {
        Connection con = MDBConnection.createConnection();
        try {
           con.setAutoCommit(false);
        String querySelect = "select username, password, userType from login where username = ? AND userType = ?";
        PreparedStatement cmd = con.prepareStatement(querySelect);
        cmd.setString(1, username);
        cmd.setString(2, userType);

        ResultSet reader = cmd.executeQuery();

        if (reader.next()) {
            String dbPassword = reader.getString("password");
            if (dbPassword.equals(password)) {
                User user = new User();
                user.setUsername(reader.getString("username"));
                user.setRole(reader.getString("userType"));
                return user;
            } else {
                System.out.println("Invalid password");
                return null;
            }
        } else {
            System.out.println("No user found");
            return null;
        }
    } catch (SQLException e) {
        throw new RuntimeException(e);
    } finally {
        try {
            con.close();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
    }



    public class User {

        private String username;
        private String role;

        public User() {
        } // Add this default constructor

        public String getUsername() {
            return username;
        }

        public void setUsername(String username) {
            this.username = username;
        }

        public String getRole() {
            return role;
        }

        public void setRole(String role) {
            this.role = role;
        }
    }

}
