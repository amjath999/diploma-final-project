
package model;

import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JOptionPane;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JTextField;
import com.toedter.calendar.JDateChooser;
import javax.swing.JRadioButton;





public class MCustomer {
    
    public void addCustomer(String customerId,String customerName,Date DoB,String Gender,String Address,String Email,String Mobile)
    {
   
        Connection con = MDBConnection.createConnection();
        
        try
        {
            
            SimpleDateFormat x = new SimpleDateFormat("yyyy-MM-dd");
            String dob_new = x.format(DoB);
            Statement st = MDBConnection.createConnection().createStatement();
            System.out.print(dob_new);
            int count = st.executeUpdate("insert into CustomerDetail values('"+customerId+"','"+customerName+"','"+DoB+"','"+Gender+"','"+Address+"','"+Email+"','"+Mobile+"')");
            if(count>0)
            {
                JOptionPane.showMessageDialog(null, "Registered", "Information", JOptionPane.INFORMATION_MESSAGE);
            }
        }
        catch(SQLException e)
        {
            System.err.println(e.getMessage());
            
        }
    }
    public void displayCustomer(String customerId,JTextField[] fields,JRadioButton[] radioButtons, JDateChooser datePicker)
    {
        Connection con = MDBConnection.createConnection();
          try (PreparedStatement pstmt = con.prepareStatement("SELECT customerId,customerName,DoB,Gender,Address, Email, Mobile FROM CustomerDetail WHERE customerId =?")) {
            pstmt.setString(1, customerId);
            
            try (ResultSet rs = pstmt.executeQuery()) {
          
                if (rs.next()) {
                     
                    fields[0].setText(rs.getString("customerId"));
                    fields[1].setText(rs.getString("customerName"));

                    

                    fields[2].setText(rs.getString("Address"));
                    fields[3].setText(rs.getString("Email"));
                    fields[4].setText(rs.getString("Mobile"));
                    
                     // Set the date of birth
                  Date dob = rs.getDate("DoB");
                  if (dob != null) {
                    datePicker.setDate(dob);
                  } else {
                    datePicker.setDate(null);
                  }
                  
                   // Set the gender radio button
                String gender = rs.getString("Gender");
                if ("M".equals(gender)) {
                    radioButtons[0].setSelected(true);
                } else if ("F".equals(gender)) {
                    radioButtons[1].setSelected(true);
                } else {
                    radioButtons[0].setSelected(false);
                    radioButtons[1].setSelected(false);
                }
                } else {
                    JOptionPane.showMessageDialog(null, "Customer not found","Invalid ID",JOptionPane.ERROR_MESSAGE);
                }
            }
        } catch (SQLException e) {
            // Handle the SQL exception
            e.printStackTrace();
        }
    }
   
    
    
        
    
    
         
        
         
    

   

         
        
  
        public void updateCustomer(String customerId,String customerName,Date DoB,String Gender,String Address,String Email,String Mobile)
        {
             Connection con = MDBConnection.createConnection();
    try {
        // Update customer details in database
        String query = "UPDATE CustomerDetail SET customerName =?, DoB =?, Gender =?, Address =?, Email =?, Mobile =? WHERE customerID =?";
        PreparedStatement pstmt = con.prepareStatement(query);
        
        pstmt.setString(1, customerName);
        pstmt.setDate(2, new java.sql.Date(DoB.getTime())); // Convert java.util.Date to java.sql.Date
        pstmt.setString(3, Gender);
        pstmt.setString(4, Address);
        pstmt.setString(5, Email);
        pstmt.setString(6, Mobile);
        pstmt.setString(7, customerId);
        
        int count = pstmt.executeUpdate();
        if (count > 0) {
            JOptionPane.showMessageDialog(null, "Customer details updated successfully!", "Information", JOptionPane.INFORMATION_MESSAGE);
        }
    } catch (SQLException ex) {
        System.err.println(ex.getMessage());
    }
    
            }
        public void deleteCustomer(String customerId) {
    Connection con = MDBConnection.createConnection();
    try {
        int confirm = JOptionPane.showConfirmDialog(null, "Are you sure you want to delete this customer?", "Confirm Delete", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            String query = "delete from CustomerDetail where customerID =?";
            PreparedStatement pstmt = con.prepareStatement(query);
            pstmt.setString(1, customerId);
            int count = pstmt.executeUpdate();
            if (count > 0) {
                JOptionPane.showMessageDialog(null, "Customer deleted successfully!", "Information", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(null, "Customer not found!", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    } catch (SQLException ex) {
        System.err.println(ex.getMessage());
    }
}
          
    
        
   

    
}


           

   
        


    


    
       

       
    
    




        
  
    

