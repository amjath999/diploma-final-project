
package model;
import java.sql.*;

import java.sql.SQLException;
import javax.swing.JOptionPane;
public class MSign_Up {
    
    public void createAccount(String userType,String Email,String username, String password, String Confirm_Password) {
        
        if (userType.isEmpty() || Email.isEmpty() || username.isEmpty() || password.isEmpty() || Confirm_Password.isEmpty()) {
            JOptionPane.showMessageDialog(null, "All fields are required. Please fill in all the fields.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        if (!password.equals(Confirm_Password)) {
            JOptionPane.showMessageDialog(null, "Password and Confirm Password do not match.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        try {
           
            Connection conn = MDBConnection.createConnection();
            String sql = "insert into Login (userType, Email, username, password, Confirm_Password) values (?,?,?,?,?)";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, userType);
            pstmt.setString(2, Email);
            pstmt.setString(3, username);
            pstmt.setString(4, password);
            pstmt.setString(5, Confirm_Password);
            
            int count = pstmt.executeUpdate();
            
            if (count > 0) {
                JOptionPane.showMessageDialog(null, "You have been successfully registered.", "Information", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(null, "Encountered an error. Please review your fields and try again later!", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "An error occurred: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        } 
    }
        }
    
    

