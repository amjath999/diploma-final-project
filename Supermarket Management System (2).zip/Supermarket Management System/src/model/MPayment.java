
package model;

import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JOptionPane;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JTextField;
import com.toedter.calendar.JDateChooser;
import javax.swing.JComboBox;
import javax.swing.JRadioButton;
public class MPayment {
    public void addPayment(String paymentId,String customerId,String customerName,Date paymentDate,String itemId,String itemName,int Quantity,double unitPrice,double totalAmount)
    {
   
        Connection con = MDBConnection.createConnection();
        
        try
        {
            
            SimpleDateFormat x = new SimpleDateFormat("yyyy-MM-dd");
            String pay_Date = x.format(paymentDate);
            Statement st = MDBConnection.createConnection().createStatement();
            System.out.print(pay_Date);
            int count = st.executeUpdate("insert into PaymentTable values('"+paymentId+"','"+customerId+"','"+customerName+"','"+paymentDate+"','"+itemId+"','"+itemName+"','"+Quantity+"','"+unitPrice+"','"+totalAmount+"')");
            if(count>0)
            {
                JOptionPane.showMessageDialog(null, "Payment was successfully made", "Information", JOptionPane.INFORMATION_MESSAGE);
            }
        }
        catch(SQLException e)
        {
            System.err.println(e.getMessage());
            
        }
}
     public void displayCustomerDetail(String customerId,JTextField[] fields)
    {
        Connection con = MDBConnection.createConnection();
          try (PreparedStatement pstmt = con.prepareStatement("SELECT customerName FROM CustomerDetail WHERE customerId =?")) {
            pstmt.setString(1, customerId);
           
            
            try (ResultSet rs = pstmt.executeQuery()) {
          
                if (rs.next()) {
                     
                 
                    fields[0].setText(rs.getString("customerName"));
                    
                     

                    

                    
                    
                 
                  
                 
                
                } else {
                    JOptionPane.showMessageDialog(null, "Customer not found","Invalid ID",JOptionPane.ERROR_MESSAGE);
                }
            }
        } catch (SQLException e) {
            // Handle the SQL exception
            e.printStackTrace();
        }
    }
    
    
     public void updatePayment(String paymentId,String customerId,String customerName,Date paymentDate,String itemId,String itemType,String itemName,int Quantity,double unitPrice,double totalAmount)
     {
          Connection con = MDBConnection.createConnection();
    try {
        // Update customer details in database
        String query = "UPDATE Payments SET customerId =?, customerName =?, paymentDate =?,itemId =?, itemType =?, itemName =?, Quantity =?,unitPrice =?,totalAmount =? WHERE paymentId =?";
        PreparedStatement pstmt = con.prepareStatement(query);
        
        pstmt.setString(1, customerId);
        
        pstmt.setString(2, customerName);
        pstmt.setDate(3, new java.sql.Date(paymentDate.getTime())); // Convert java.util.Date to java.sql.Date
        pstmt.setString(4, itemId);
        pstmt.setString(5, itemType);
        pstmt.setString(6, itemName);
        pstmt.setInt(7,Quantity);
        pstmt.setDouble(7,unitPrice);
        pstmt.setDouble(7,totalAmount);
        
        int count = pstmt.executeUpdate();
        if (count > 0) {
            JOptionPane.showMessageDialog(null, "Payment details updated successfully!", "Information", JOptionPane.INFORMATION_MESSAGE);
        }
    } catch (SQLException ex) {
        System.err.println(ex.getMessage());
    }
     }
      public void deletePayment(String paymentId) {
    Connection con = MDBConnection.createConnection();
    try {
        int confirm = JOptionPane.showConfirmDialog(null, "Are you sure you want to delete this Customer Payment?", "Confirm Delete", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            String query = "delete from Payments where paymentId =?";
            PreparedStatement pstmt = con.prepareStatement(query);
            pstmt.setString(1, paymentId);
            int count = pstmt.executeUpdate();
            if (count > 0) {
                JOptionPane.showMessageDialog(null, "Payment deleted successfully!", "Information", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(null, "Payment not found!", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    } catch (SQLException ex) {
        System.err.println(ex.getMessage());
    }
     
      }
      
 public void displayItemDetail(String itemId, JTextField[] fields, JComboBox <String> comboBox) {
    
     
     Connection con = MDBConnection.createConnection();
    try (PreparedStatement pstmt = con.prepareStatement("SELECT itemName, itemType,unitprice FROM itemdetail WHERE itemId =?")) {
        pstmt.setString(1, itemId);
        try (ResultSet rs = pstmt.executeQuery()) {
            if (rs.next()) {
                fields[0].setText(rs.getString("itemName"));
                fields[1].setText(rs.getString("unitprice"));
                comboBox.setSelectedItem(rs.getString("itemType"));
            } else {
                JOptionPane.showMessageDialog(null, "Item not found", "Invalid ID", JOptionPane.ERROR_MESSAGE);
            }
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
}

    private static class comboBoxes {

        private static int getItemCount() {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }

        private static Object getItemAt(int i) {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }

        private static void setSelectedIndex(int i) {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }

        public comboBoxes() {
        }
    }
}
   
    
    
        
    
    
         
        
         
    

   

         


