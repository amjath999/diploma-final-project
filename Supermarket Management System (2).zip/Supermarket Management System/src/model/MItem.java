
package model;

import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JOptionPane;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JTextField;
import com.toedter.calendar.JDateChooser;
import javax.swing.JComboBox;


public class MItem {
    
  
    
    public void clearFields(JTextField[] fields, JComboBox<String> comboBox, JDateChooser datepicker) {
        for (JTextField field : fields) {
            field.setText("");
        }
        comboBox.setSelectedIndex(0); // or comboBox.setSelectedItem(null) if you want to deselect all items
        datepicker.setDate(null);
    }
   
    public void addItem(String itemId, String itemName, String itemType, Date issuedDate, int Quantity, double unitprice, String Description,JTextField[] fields, JComboBox<String> comboBox, JDateChooser datepicker) {
        Connection con = MDBConnection.createConnection();
        
        try {
            String query = "insert into itemdetail values(?,?,?,?,?,?,?)";
            PreparedStatement st = con.prepareStatement(query);
            
            st.setString(1, itemId);
            st.setString(2, itemName);
            st.setString(3, (String) comboBox.getSelectedItem()); // Get the selected item from the JComboBox
            st.setDate(4, new java.sql.Date(issuedDate.getTime())); // Convert java.util.Date to java.sql.Date
            st.setInt(5, Quantity);
            st.setDouble(6, unitprice);
            st.setString(7, Description);
            
            int count = st.executeUpdate();
            if(count > 0) {
                JOptionPane.showMessageDialog(null, "Item inserted successfully", "Information", JOptionPane.INFORMATION_MESSAGE);
                clearFields(fields, comboBox, datepicker);
                
            }
        } catch(SQLException e) {
            System.err.println(e.getMessage());
        }
    }
    
    public boolean displayItem(String itemId,JTextField [] fields,JComboBox<String>comboBoxes, JDateChooser datepicker) {
        
        if (itemId == null || itemId.trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Item ID is required", "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        if (itemId.length() == 1 && itemId.equals("I")) {
            // Allow "I" as a valid input
            return true;
        }
        if (!itemId.matches("I\\d+")) {
            JOptionPane.showMessageDialog(null, "Invalid item ID. Item ID should start with 'I' and followed by a number.", "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        try (Connection con = MDBConnection.createConnection();
                PreparedStatement stmt = con.prepareStatement("SELECT * FROM itemdetail WHERE itemId =?")) {
            stmt.setString(1, itemId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    // Set the text fields
                    fields[0].setText(rs.getString("itemName"));
                    fields[1].setText(String.valueOf(rs.getInt("Quantity")));
                    fields[2].setText(String.valueOf(rs.getDouble("unitprice")));
                    fields[3].setText(rs.getString("description"));
                    
                    // Set the combo boxes
                    String itemType = rs.getString("itemType");
                    for (int i = 0; i < comboBoxes.getItemCount(); i++) {
                        if (comboBoxes.getItemAt(i).equals(itemType)) {
                            comboBoxes.setSelectedIndex(i);
                            break;
                        }
                    }
                    
                    Date issuedDate = rs.getDate("issuedDate");
                    if (issuedDate != null) {
                        datepicker.setDate(issuedDate);
                    } else {
                        datepicker.setDate(null);
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Item not found", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
        return false;
    }
    
    public void updateItem(String itemId, String itemName, String itemType, Date issuedDate, int Quantity, double unitprice, String Description,JComboBox <String> comboBox) {
        
        Connection con = MDBConnection.createConnection();
        try {
            // Update item details in database
            String query = "UPDATE itemdetail SET itemName =?, itemType =?, issuedDate =?, Quantity =?, unitprice =?, description =? WHERE itemID =?";
            PreparedStatement pstmt = con.prepareStatement(query);
            
            pstmt.setString(1, itemName);
            
            pstmt.setString(2, (String) comboBox.getSelectedItem()); // Get the selected item from the JComboBox
            pstmt.setDate(3, new java.sql.Date(issuedDate.getTime())); // Convert java.util.Date to java.sql.Date
            pstmt.setInt(4, Quantity);
            pstmt.setDouble(5, unitprice);
            pstmt.setString(6, Description);
            pstmt.setString(7, itemId);
            
            int count = pstmt.executeUpdate();
            if (count > 0) {
                JOptionPane.showMessageDialog(null, "Item details updated successfully!", "Information", JOptionPane.INFORMATION_MESSAGE);
            }
        } catch (SQLException ex) {
            System.err.println(ex.getMessage());
        }
    }
    
    public void deleteItem(String itemId)
    {
         Connection con = MDBConnection.createConnection();
        try {
        int confirm = JOptionPane.showConfirmDialog(null, "Are you sure you want to delete this Item?", "Confirm Delete", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            String query = "delete from itemdetail where itemID =?";
            PreparedStatement pstmt = con.prepareStatement(query);
            pstmt.setString(1, itemId);
            int count = pstmt.executeUpdate();
            if (count > 0) {
                JOptionPane.showMessageDialog(null, "Item deleted successfully!", "Information", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(null, "Item not found!", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    } catch (SQLException ex) {
        System.err.println(ex.getMessage());
    }
        
    }
 
 

 
 
    

    public boolean isItemIdValid(String itemId) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
   
}
    






   
  

