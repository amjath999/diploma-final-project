
package controller;

import com.toedter.calendar.JDateChooser;
import javax.swing.JComboBox;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import model.MItem;

public class CSearch_Item {
    
    public void displayItem(String itemId,JTextField[] fields, JDateChooser datePicker,JComboBox<String> itemTypeComboBox)
         {
            
             MItem displayItemDetails = new MItem();
             displayItemDetails.displayItem(itemId, fields,itemTypeComboBox, datePicker);
         }

    
    
}
