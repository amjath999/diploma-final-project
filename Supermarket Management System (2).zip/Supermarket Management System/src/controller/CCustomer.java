
package controller;
import com.toedter.calendar.JDateChooser;
import  java.util.Date;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import model.MCustomer;

public class CCustomer {
    
        public void addCustomer(String customerId,String customerName,Date DoB,String Gender,String Address,String Email,String Mobile)
        {
            java.sql.Date sqlDob = new java.sql.Date(DoB.getTime());
            MCustomer customerAdd = new MCustomer();
            customerAdd.addCustomer(customerId, customerName, sqlDob, Gender, Address, Email, Mobile);
        }
        public void updateCustomer(String customerId,String customerName,Date DoB,String Gender,String Address,String Email,String Mobile)
        {
            java.sql.Date sqlDob = new java.sql.Date(DoB.getTime());
            MCustomer customerUpdate = new MCustomer();
            customerUpdate.updateCustomer(customerId, customerName, sqlDob, Gender, Address, Email, Mobile);
        }
        public void displayCustomer(String customerId,JTextField[] fields,JRadioButton[] radioButtons, JDateChooser datePicker)
        {
            MCustomer displayCustomer = new MCustomer();
            displayCustomer.displayCustomer(customerId, fields,radioButtons,datePicker);
        }
        public void deleteCustomer(String customerId) 
        {
            MCustomer deleteCustomer = new MCustomer();
            deleteCustomer.deleteCustomer(customerId);
        }




    
            
    
}
