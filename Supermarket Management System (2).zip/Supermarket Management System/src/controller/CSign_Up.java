
package controller;

import java.util.Date;
import model.MSign_Up;

public class CSign_Up {
    
        public void createAccount(String userType, String Email, String username, String password, String Confirm_Password)
        {
            MSign_Up createAccount = new MSign_Up();
            createAccount.createAccount(userType, Email, username, password, Confirm_Password);
        }

       

}
