
package controller;

import com.toedter.calendar.JDateChooser;
import java.util.Date;
import javax.swing.JComboBox;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import model.MPayment;


public class CPayment {
        public void addPayment(String paymentId,String customerId,String customerName,Date paymentDate,String itemId,String itemName,int Quantity,double unitPrice,double totalAmount)
        {
            MPayment addPayment = new MPayment();
            addPayment.addPayment(paymentId, customerId, customerName, paymentDate, itemId, itemName, Quantity, unitPrice, totalAmount);
            
        }
        public void displayCustomerDetail(String customerId,JTextField[] fields)
        {
            MPayment selectCustomer = new MPayment();
            selectCustomer.displayCustomerDetail(customerId, fields);
        }
        public void displayItemDetail(String itemId,JTextField[] fields,JComboBox <String> comboBox)
        {
            MPayment displayItem = new MPayment();
            displayItem.displayItemDetail(itemId, fields, comboBox);
        }
        public void updatePayment(String paymentId,String customerId,String customerName,Date paymentDate,String itemId,String itemType,String itemName,int Quantity,double unitPrice,double totalAmount)
        {
            MPayment updatePay = new MPayment();
            updatePay.updatePayment(paymentId, customerId, customerName, paymentDate, itemId, itemType, itemName, Quantity, unitPrice, totalAmount);
        }




}
