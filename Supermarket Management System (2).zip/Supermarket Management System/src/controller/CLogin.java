
package controller;
import model.MLogin;

public class CLogin {
        public MLogin.User login(String userType, String username, String password) {
        MLogin login = new MLogin();
        return login.login(userType, username, password);
        }

}
