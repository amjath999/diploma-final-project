
package controller;

import com.toedter.calendar.JDateChooser;
import java.util.Date;
import javax.swing.JComboBox;
import javax.swing.JTextField;
import model.MItem;


public class CItem {
    
         public void addItem(String itemId,String itemName,String itemType,Date issuedDate,int Quantity,double unitprice,String Description,JTextField[] fields, JComboBox<String> comboBox, JDateChooser datepicker)
         {
              java.sql.Date sqlissued = new java.sql.Date(issuedDate.getTime());
              MItem addItemDetails = new MItem();
              addItemDetails.addItem(itemId, itemName, itemType, issuedDate, Quantity, unitprice, Description, fields, comboBox, datepicker);
                      
         }
         public void displayItem(String itemId,JTextField[] fields, JDateChooser datePicker,JComboBox<String> itemTypeComboBox)
         {
            
             MItem displayItemDetails = new MItem();
             displayItemDetails.displayItem(itemId, fields,itemTypeComboBox, datePicker);
         }
        public void updateItem(String itemId, String itemName, String itemType, Date issuedDate, int Quantity, double unitprice, String Description,JComboBox<String>comboBoxes) {

           java.sql.Date sqlissued = new java.sql.Date(issuedDate.getTime());
            MItem updateItemDetails = new MItem();
            updateItemDetails.updateItem(itemId, itemName, itemType, issuedDate, Quantity, unitprice, Description, comboBoxes);
                    
        }
        public void deleteItem(String itemId)
        {
            MItem deleteItemDetail = new MItem();
            deleteItemDetail.deleteItem(itemId);
                    
        }



    
}
