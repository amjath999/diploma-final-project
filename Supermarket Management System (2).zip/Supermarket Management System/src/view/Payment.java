
package view;
import controller.CPayment;
import java.awt.event.KeyEvent;
import java.util.Date;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import model.MCustomer;
import model.MPayment;
public class Payment extends javax.swing.JFrame {
    
    

   private MPayment model;
    private boolean addButton;
    private boolean updateButton;
    private boolean clearButton;
    private boolean deleteButton;
    private Date paymentDate;
    public Payment() {
        initComponents();
        model = new MPayment();
    }

    
    
   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        cmbItemType = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        txt_Payment_Id = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        txt_Customer_Name = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        txt_Unit_Price = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        txt_Total_Amount = new javax.swing.JTextField();
        btn_Add_Payment = new javax.swing.JButton();
        btn_Update_Payment = new javax.swing.JButton();
        btn_Clear = new javax.swing.JButton();
        btn_Delete_Payment = new javax.swing.JButton();
        dtp_PaymentDate = new com.toedter.calendar.JDateChooser();
        cmb_Item_Id = new javax.swing.JComboBox<>();
        jLabel10 = new javax.swing.JLabel();
        txt_Item_Name = new javax.swing.JTextField();
        cmb_Item_Type = new javax.swing.JComboBox<>();
        jLabel11 = new javax.swing.JLabel();
        txt_Quantity2 = new javax.swing.JTextField();
        cmb_Customer_Type = new javax.swing.JComboBox<>();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setPreferredSize(new java.awt.Dimension(715, 508));
        getContentPane().setLayout(null);

        jPanel1.setBackground(new java.awt.Color(51, 255, 51));
        jPanel1.setLayout(null);

        cmbItemType.setBackground(new java.awt.Color(255, 255, 255));
        cmbItemType.setLayout(null);

        jLabel1.setFont(new java.awt.Font("Calibri", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 0, 0));
        jLabel1.setText("Manage Payment");
        cmbItemType.add(jLabel1);
        jLabel1.setBounds(220, 20, 220, 60);

        jLabel2.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 0, 0));
        jLabel2.setText("Payment Id");
        cmbItemType.add(jLabel2);
        jLabel2.setBounds(80, 90, 80, 20);

        txt_Payment_Id.setBackground(new java.awt.Color(255, 255, 255));
        cmbItemType.add(txt_Payment_Id);
        txt_Payment_Id.setBounds(80, 120, 120, 28);

        jLabel3.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(0, 0, 0));
        jLabel3.setText("Customer Id");
        cmbItemType.add(jLabel3);
        jLabel3.setBounds(80, 160, 80, 20);

        jLabel4.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(0, 0, 0));
        jLabel4.setText("Customer Name");
        cmbItemType.add(jLabel4);
        jLabel4.setBounds(80, 220, 100, 20);

        txt_Customer_Name.setBackground(new java.awt.Color(255, 255, 255));
        cmbItemType.add(txt_Customer_Name);
        txt_Customer_Name.setBounds(80, 240, 120, 28);

        jLabel5.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(0, 0, 0));
        jLabel5.setText("Item Id");
        cmbItemType.add(jLabel5);
        jLabel5.setBounds(80, 340, 80, 20);

        jLabel6.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(0, 0, 0));
        jLabel6.setText("Date ");
        cmbItemType.add(jLabel6);
        jLabel6.setBounds(80, 280, 80, 20);

        jLabel7.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(0, 0, 0));
        jLabel7.setText("Item Name");
        cmbItemType.add(jLabel7);
        jLabel7.setBounds(280, 150, 80, 20);

        jLabel8.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(0, 0, 0));
        jLabel8.setText("Unit Price");
        cmbItemType.add(jLabel8);
        jLabel8.setBounds(280, 260, 80, 20);

        txt_Unit_Price.setBackground(new java.awt.Color(255, 255, 255));
        cmbItemType.add(txt_Unit_Price);
        txt_Unit_Price.setBounds(280, 290, 120, 28);

        jLabel9.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(0, 0, 0));
        jLabel9.setText("Total Amount");
        cmbItemType.add(jLabel9);
        jLabel9.setBounds(280, 330, 80, 20);

        txt_Total_Amount.setBackground(new java.awt.Color(255, 255, 255));
        txt_Total_Amount.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_Total_AmountActionPerformed(evt);
            }
        });
        cmbItemType.add(txt_Total_Amount);
        txt_Total_Amount.setBounds(280, 360, 120, 28);

        btn_Add_Payment.setBackground(new java.awt.Color(0, 153, 255));
        btn_Add_Payment.setForeground(new java.awt.Color(0, 0, 0));
        btn_Add_Payment.setText("Add ");
        btn_Add_Payment.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_Add_PaymentActionPerformed(evt);
            }
        });
        cmbItemType.add(btn_Add_Payment);
        btn_Add_Payment.setBounds(500, 130, 73, 28);

        btn_Update_Payment.setBackground(new java.awt.Color(255, 153, 0));
        btn_Update_Payment.setForeground(new java.awt.Color(0, 0, 0));
        btn_Update_Payment.setText("Update");
        btn_Update_Payment.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_Update_PaymentActionPerformed(evt);
            }
        });
        cmbItemType.add(btn_Update_Payment);
        btn_Update_Payment.setBounds(500, 180, 73, 28);

        btn_Clear.setBackground(new java.awt.Color(204, 204, 204));
        btn_Clear.setForeground(new java.awt.Color(0, 0, 0));
        btn_Clear.setText("Clear");
        btn_Clear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_ClearActionPerformed(evt);
            }
        });
        cmbItemType.add(btn_Clear);
        btn_Clear.setBounds(500, 280, 73, 28);

        btn_Delete_Payment.setBackground(new java.awt.Color(255, 51, 0));
        btn_Delete_Payment.setForeground(new java.awt.Color(0, 0, 0));
        btn_Delete_Payment.setText("Delete");
        cmbItemType.add(btn_Delete_Payment);
        btn_Delete_Payment.setBounds(500, 230, 73, 28);

        dtp_PaymentDate.setBackground(new java.awt.Color(255, 255, 255));
        cmbItemType.add(dtp_PaymentDate);
        dtp_PaymentDate.setBounds(80, 310, 160, 28);

        cmb_Item_Id.setBackground(new java.awt.Color(255, 255, 255));
        cmb_Item_Id.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "I1", "I2", "I3" }));
        cmb_Item_Id.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmb_Item_IdActionPerformed(evt);
            }
        });
        cmbItemType.add(cmb_Item_Id);
        cmb_Item_Id.setBounds(80, 360, 120, 26);

        jLabel10.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(0, 0, 0));
        jLabel10.setText("Item Type");
        cmbItemType.add(jLabel10);
        jLabel10.setBounds(280, 90, 80, 20);

        txt_Item_Name.setBackground(new java.awt.Color(255, 255, 255));
        cmbItemType.add(txt_Item_Name);
        txt_Item_Name.setBounds(280, 170, 120, 28);

        cmb_Item_Type.setBackground(new java.awt.Color(255, 255, 255));
        cmb_Item_Type.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Beverages", "Food", "Other", " ", " " }));
        cmb_Item_Type.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmb_Item_TypeActionPerformed(evt);
            }
        });
        cmbItemType.add(cmb_Item_Type);
        cmb_Item_Type.setBounds(280, 120, 120, 26);

        jLabel11.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(0, 0, 0));
        jLabel11.setText("Quantity");
        cmbItemType.add(jLabel11);
        jLabel11.setBounds(280, 200, 80, 20);

        txt_Quantity2.setBackground(new java.awt.Color(255, 255, 255));
        cmbItemType.add(txt_Quantity2);
        txt_Quantity2.setBounds(280, 220, 120, 28);

        cmb_Customer_Type.setBackground(new java.awt.Color(255, 255, 255));
        cmb_Customer_Type.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "C1", "C2", "C3" }));
        cmb_Customer_Type.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmb_Customer_TypeActionPerformed(evt);
            }
        });
        cmbItemType.add(cmb_Customer_Type);
        cmb_Customer_Type.setBounds(80, 180, 120, 26);

        jPanel1.add(cmbItemType);
        cmbItemType.setBounds(50, 30, 610, 400);

        getContentPane().add(jPanel1);
        jPanel1.setBounds(-10, 0, 710, 470);

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btn_Update_PaymentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_Update_PaymentActionPerformed
        String paymentId = txt_Payment_Id.getText();
        String customerId = cmb_Customer_Type.getSelectedItem().toString();
        String customerName = txt_Customer_Name.getText();
        Date paymentDate = dtp_PaymentDate.getDate();
        String itemId = cmb_Item_Id.getSelectedItem().toString();
        String itemType = cmb_Item_Type.getSelectedItem().toString();
        String itemName = txt_Item_Name.getText();
        int Quantity = Integer.parseInt(txt_Quantity2.getText());
        double unitPrice = Double.parseDouble(txt_Unit_Price.getText());
        double totalAmount = Double.parseDouble(txt_Total_Amount.getText());
       CPayment updatePay = new CPayment();
       updatePay.updatePayment(paymentId, customerId, customerName, paymentDate, itemId, itemType, itemName, Quantity, unitPrice, totalAmount);
      
    }//GEN-LAST:event_btn_Update_PaymentActionPerformed

    private void btn_Add_PaymentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_Add_PaymentActionPerformed
        String paymentId = txt_Payment_Id.getText();
        String customerId = cmb_Customer_Type.getSelectedItem().toString();
        String customerName = txt_Customer_Name.getText();
        Date paymentDate = dtp_PaymentDate.getDate();
        String itemId = cmb_Item_Id.getSelectedItem().toString();
        String itemType = cmb_Item_Type.getSelectedItem().toString();
        String itemName = txt_Item_Name.getText();
        int Quantity = Integer.parseInt(txt_Quantity2.getText());
        double unitPrice = Double.parseDouble(txt_Unit_Price.getText());
        double totalAmount = Double.parseDouble(txt_Total_Amount.getText());
       CPayment addPay = new CPayment();
       addPay.addPayment(paymentId, customerId, customerName, paymentDate, itemId, itemName, Quantity, unitPrice, totalAmount);
        
    }//GEN-LAST:event_btn_Add_PaymentActionPerformed

    private void cmb_Customer_TypeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmb_Customer_TypeActionPerformed
        
        String selectedCustomerId = (String) cmb_Customer_Type.getSelectedItem();
        JTextField[] fields = {txt_Customer_Name};
       
            
        
        model.displayCustomerDetail(selectedCustomerId, fields);
        
    }//GEN-LAST:event_cmb_Customer_TypeActionPerformed

    
    private void cmb_Item_TypeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmb_Item_TypeActionPerformed
       
        
        
            
    
    }//GEN-LAST:event_cmb_Item_TypeActionPerformed

    private void btn_ClearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_ClearActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btn_ClearActionPerformed

    private void cmb_Item_IdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmb_Item_IdActionPerformed
        
       String selectedItemId = (String) cmb_Item_Id.getSelectedItem();
       JTextField[] fields = {txt_Item_Name,txt_Unit_Price};
       JComboBox<String> itemTypeComboBox = cmb_Item_Type;
       model.displayItemDetail(selectedItemId, fields, itemTypeComboBox);
    }//GEN-LAST:event_cmb_Item_IdActionPerformed

    private void txt_Quantity2FocusLost(java.awt.event.FocusEvent evt) {                                        
    
}

private void txt_Unit_PriceFocusLost(java.awt.event.FocusEvent evt) {                                        
    
}
    private void txt_Total_AmountActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_Total_AmountActionPerformed
       
            
            try {
                int quantity = Integer.parseInt(txt_Quantity2.getText());
                double unitPrice = Double.parseDouble(txt_Unit_Price.getText());
                double totalAmount = calculateTotalAmount(quantity, unitPrice);
                totalAmountField.setText(String.valueOf(totalAmount));
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Invalid quantity or unit price", "Error", JOptionPane.ERROR_MESSAGE);
            }
        
        
        
    }//GEN-LAST:event_txt_Total_AmountActionPerformed
  
     private double calculateTotalAmount(int quantity, double unitPrice) {
        return quantity * unitPrice;
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Payment.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Payment.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Payment.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Payment.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Payment().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_Add_Payment;
    private javax.swing.JButton btn_Clear;
    private javax.swing.JButton btn_Delete_Payment;
    private javax.swing.JButton btn_Update_Payment;
    private javax.swing.JPanel cmbItemType;
    private javax.swing.JComboBox<String> cmb_Customer_Type;
    private javax.swing.JComboBox<String> cmb_Item_Id;
    private javax.swing.JComboBox<String> cmb_Item_Type;
    private com.toedter.calendar.JDateChooser dtp_PaymentDate;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JTextField txt_Customer_Name;
    private javax.swing.JTextField txt_Item_Name;
    private javax.swing.JTextField txt_Payment_Id;
    private javax.swing.JTextField txt_Quantity2;
    private javax.swing.JTextField txt_Total_Amount;
    private javax.swing.JTextField txt_Unit_Price;
    // End of variables declaration//GEN-END:variables

    private static class totalAmountField {

        private static void setText(String valueOf) {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }

        public totalAmountField() {
        }
    }
}
