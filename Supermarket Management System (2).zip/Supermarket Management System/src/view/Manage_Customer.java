
package view;


import java.util.Date;
import com.toedter.calendar.JDateChooser;
import javax.swing.JTextField;


import model.MCustomer;



import controller.CCustomer;
import javax.swing.JRadioButton;
public class Manage_Customer extends javax.swing.JFrame {

    private MCustomer model;
    
   
  
    public Manage_Customer() {
        initComponents();
        model = new MCustomer();
      
      
        
    }
      
        
        
    
    

     
     
   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jComboBox1 = new javax.swing.JComboBox<>();
        buttonGroup1 = new javax.swing.ButtonGroup();
        buttonGroup2 = new javax.swing.ButtonGroup();
        buttonGroup3 = new javax.swing.ButtonGroup();
        buttonGroup4 = new javax.swing.ButtonGroup();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        txt_Customer_Id = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        txt_Mobile = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        txt_Address = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        txt_Customer_Name = new javax.swing.JTextField();
        dtp_Dob = new com.toedter.calendar.JDateChooser();
        rdb_Female = new javax.swing.JRadioButton();
        rdb_Male = new javax.swing.JRadioButton();
        jLabel8 = new javax.swing.JLabel();
        txt_Email = new javax.swing.JTextField();
        btn_Clear = new javax.swing.JButton();
        btn_Add_Customer = new javax.swing.JButton();
        btn_Update_Customer = new javax.swing.JButton();
        jLabel9 = new javax.swing.JLabel();
        cmbCustomerId = new javax.swing.JComboBox<>();
        btn_Delete_Customer1 = new javax.swing.JButton();

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        jPanel1.setBackground(new java.awt.Color(51, 255, 51));
        jPanel1.setLayout(null);

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setLayout(null);

        jLabel1.setFont(new java.awt.Font("Calibri", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 0, 0));
        jLabel1.setText("Manage Customer");
        jPanel2.add(jLabel1);
        jLabel1.setBounds(150, 20, 190, 30);

        jLabel2.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 0, 0));
        jLabel2.setText("Customer Id");
        jPanel2.add(jLabel2);
        jLabel2.setBounds(40, 70, 80, 20);

        txt_Customer_Id.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.add(txt_Customer_Id);
        txt_Customer_Id.setBounds(40, 100, 120, 28);

        jLabel3.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(0, 0, 0));
        jLabel3.setText("Customer Name");
        jPanel2.add(jLabel3);
        jLabel3.setBounds(40, 140, 110, 20);

        txt_Mobile.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.add(txt_Mobile);
        txt_Mobile.setBounds(220, 250, 120, 28);

        jLabel4.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(0, 0, 0));
        jLabel4.setText("DoB");
        jPanel2.add(jLabel4);
        jLabel4.setBounds(40, 220, 100, 20);

        jLabel5.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(0, 0, 0));
        jLabel5.setText("Address");
        jPanel2.add(jLabel5);
        jLabel5.setBounds(220, 70, 80, 20);

        txt_Address.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.add(txt_Address);
        txt_Address.setBounds(220, 100, 120, 28);

        jLabel6.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(0, 0, 0));
        jLabel6.setText("Gender");
        jPanel2.add(jLabel6);
        jLabel6.setBounds(40, 280, 100, 20);

        jLabel7.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(0, 0, 0));
        jLabel7.setText("Mobile Number");
        jPanel2.add(jLabel7);
        jLabel7.setBounds(220, 220, 100, 20);

        txt_Customer_Name.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.add(txt_Customer_Name);
        txt_Customer_Name.setBounds(40, 170, 120, 28);

        dtp_Dob.setBackground(new java.awt.Color(255, 255, 255));
        dtp_Dob.setForeground(new java.awt.Color(255, 255, 255));
        jPanel2.add(dtp_Dob);
        dtp_Dob.setBounds(40, 240, 160, 28);

        buttonGroup1.add(rdb_Female);
        rdb_Female.setForeground(new java.awt.Color(0, 0, 0));
        rdb_Female.setText("Female");
        jPanel2.add(rdb_Female);
        rdb_Female.setBounds(130, 310, 100, 18);

        buttonGroup1.add(rdb_Male);
        rdb_Male.setForeground(new java.awt.Color(0, 0, 0));
        rdb_Male.setText("Male");
        jPanel2.add(rdb_Male);
        rdb_Male.setBounds(40, 310, 100, 18);

        jLabel8.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(0, 0, 0));
        jLabel8.setText("Email");
        jPanel2.add(jLabel8);
        jLabel8.setBounds(220, 140, 80, 20);

        txt_Email.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.add(txt_Email);
        txt_Email.setBounds(220, 170, 120, 28);

        btn_Clear.setBackground(new java.awt.Color(204, 204, 204));
        btn_Clear.setForeground(new java.awt.Color(0, 0, 0));
        btn_Clear.setText("Clear");
        btn_Clear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_ClearActionPerformed(evt);
            }
        });
        jPanel2.add(btn_Clear);
        btn_Clear.setBounds(390, 240, 73, 28);

        btn_Add_Customer.setBackground(new java.awt.Color(0, 153, 255));
        btn_Add_Customer.setForeground(new java.awt.Color(0, 0, 0));
        btn_Add_Customer.setText("Add ");
        btn_Add_Customer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_Add_CustomerActionPerformed(evt);
            }
        });
        jPanel2.add(btn_Add_Customer);
        btn_Add_Customer.setBounds(390, 100, 73, 28);

        btn_Update_Customer.setBackground(new java.awt.Color(255, 153, 0));
        btn_Update_Customer.setForeground(new java.awt.Color(0, 0, 0));
        btn_Update_Customer.setText("Update");
        btn_Update_Customer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_Update_CustomerActionPerformed(evt);
            }
        });
        jPanel2.add(btn_Update_Customer);
        btn_Update_Customer.setBounds(390, 150, 73, 28);

        jLabel9.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(0, 0, 0));
        jLabel9.setText("Customer Id");
        jPanel2.add(jLabel9);
        jLabel9.setBounds(220, 290, 80, 20);

        cmbCustomerId.setBackground(new java.awt.Color(255, 255, 255));
        cmbCustomerId.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "C1", "C2", "C3" }));
        cmbCustomerId.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbCustomerIdActionPerformed(evt);
            }
        });
        jPanel2.add(cmbCustomerId);
        cmbCustomerId.setBounds(220, 310, 120, 26);

        btn_Delete_Customer1.setBackground(new java.awt.Color(255, 51, 0));
        btn_Delete_Customer1.setForeground(new java.awt.Color(0, 0, 0));
        btn_Delete_Customer1.setText("Delete");
        btn_Delete_Customer1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_Delete_Customer1ActionPerformed(evt);
            }
        });
        jPanel2.add(btn_Delete_Customer1);
        btn_Delete_Customer1.setBounds(390, 200, 73, 28);

        jPanel1.add(jPanel2);
        jPanel2.setBounds(40, 40, 470, 340);

        getContentPane().add(jPanel1);
        jPanel1.setBounds(-1, -8, 540, 420);

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btn_Add_CustomerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_Add_CustomerActionPerformed
        String customerId,customerName,Gender,Address,Email,Mobile;
        Date DoB = dtp_Dob.getDate();
       
        customerId = txt_Customer_Id.getText();
        customerName = txt_Customer_Name.getText();
        
       
        if(rdb_Male.isSelected())
        {
            Gender = "M";
        }
        else
        {
            Gender = "F";
        }
        Address = txt_Address.getText();
        Email = txt_Email.getText();
        Mobile = txt_Mobile.getText();
        
        CCustomer customerAdd = new CCustomer();
        customerAdd.addCustomer(customerId, customerName, DoB, Gender, Address, Email, Mobile);
        
                
        
        
                
    }//GEN-LAST:event_btn_Add_CustomerActionPerformed

    private void btn_Update_CustomerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_Update_CustomerActionPerformed
        
        String customerId,customerName,Gender,Address,Email,Mobile;
        Date DoB = dtp_Dob.getDate();
       
        customerId = txt_Customer_Id.getText();
        customerName = txt_Customer_Name.getText();
        
       
        if(rdb_Male.isSelected())
        {
            Gender = "M";
        }
        else
        {
            Gender = "F";
        }
        Address = txt_Address.getText();
        Email = txt_Email.getText();
        Mobile = txt_Mobile.getText();
        
        CCustomer customerUpdate = new CCustomer();
        customerUpdate.updateCustomer(customerId, customerName, DoB, Gender, Address, Email, Mobile);
        
        
                
    }//GEN-LAST:event_btn_Update_CustomerActionPerformed

    private void cmbCustomerIdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbCustomerIdActionPerformed
      
      
       
        
       
        
             
              String selectedCustomerId = (String) cmbCustomerId.getSelectedItem();
              JTextField[] fields = {txt_Customer_Id,txt_Customer_Name,txt_Address, txt_Email, txt_Mobile};
              JRadioButton[] radioButtons = {rdb_Male, rdb_Female};
              JDateChooser datePicker = dtp_Dob;

                            

             model.displayCustomer(selectedCustomerId, fields,radioButtons,datePicker);
    

    
    }//GEN-LAST:event_cmbCustomerIdActionPerformed

    private void btn_ClearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_ClearActionPerformed
       
         txt_Customer_Id.setText("");
         txt_Customer_Name.setText("");
         txt_Address.setText("");
         txt_Email.setText("");
         txt_Mobile.setText("");
         dtp_Dob.setDate(null); // Clear the date field
         buttonGroup1.clearSelection(); // Clear the radio button selection
  
                
       
    }//GEN-LAST:event_btn_ClearActionPerformed

    private void btn_Delete_Customer1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_Delete_Customer1ActionPerformed
         String customerId = txt_Customer_Id.getText();
        CCustomer delete = new CCustomer();
        delete.deleteCustomer(customerId);
    }//GEN-LAST:event_btn_Delete_Customer1ActionPerformed

  
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Manage_Customer.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Manage_Customer.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Manage_Customer.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Manage_Customer.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Manage_Customer().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_Add_Customer;
    private javax.swing.JButton btn_Clear;
    private javax.swing.JButton btn_Delete_Customer1;
    private javax.swing.JButton btn_Update_Customer;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.ButtonGroup buttonGroup2;
    private javax.swing.ButtonGroup buttonGroup3;
    private javax.swing.ButtonGroup buttonGroup4;
    private javax.swing.JComboBox<String> cmbCustomerId;
    private com.toedter.calendar.JDateChooser dtp_Dob;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JRadioButton rdb_Female;
    private javax.swing.JRadioButton rdb_Male;
    private javax.swing.JTextField txt_Address;
    private javax.swing.JTextField txt_Customer_Id;
    private javax.swing.JTextField txt_Customer_Name;
    private javax.swing.JTextField txt_Email;
    private javax.swing.JTextField txt_Mobile;
    // End of variables declaration//GEN-END:variables
}