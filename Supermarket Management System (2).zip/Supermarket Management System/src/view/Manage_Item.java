
package view;
import com.toedter.calendar.JDateChooser;
import java.util.Date;
import controller.CItem;
import javax.swing.JComboBox;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import model.MItem;
public class Manage_Item extends javax.swing.JFrame {

   
    public Manage_Item() {
        initComponents();
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        txt_Payment_Id = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        cmbItemType = new javax.swing.JPanel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        txt_Payment_Id6 = new javax.swing.JTextField();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        txt_Customer_Name = new javax.swing.JTextField();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        txt_Unit_Price = new javax.swing.JTextField();
        jLabel21 = new javax.swing.JLabel();
        txt_Total_Amount = new javax.swing.JTextField();
        btn_Add_Payment = new javax.swing.JButton();
        btn_Update_Payment = new javax.swing.JButton();
        btn_Clear = new javax.swing.JButton();
        btn_Delete_Payment = new javax.swing.JButton();
        dtp_PaymentDate = new com.toedter.calendar.JDateChooser();
        cmb_Item_Id = new javax.swing.JComboBox<>();
        jLabel22 = new javax.swing.JLabel();
        txt_Item_Name = new javax.swing.JTextField();
        cmb_Item_Type = new javax.swing.JComboBox<>();
        jLabel23 = new javax.swing.JLabel();
        txt_Quantity2 = new javax.swing.JTextField();
        cmb_Customer_Type = new javax.swing.JComboBox<>();
        jButton4 = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        txt_Quantity = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        txt_Item_Id = new javax.swing.JTextField();
        cmb_Type = new javax.swing.JComboBox<>();
        jLabel8 = new javax.swing.JLabel();
        dtp_Issued_Date = new com.toedter.calendar.JDateChooser();
        jLabel10 = new javax.swing.JLabel();
        txt_Description = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        txt_Item_name = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        txt_Unitprice = new javax.swing.JTextField();
        btn_Reset = new javax.swing.JButton();
        btn_Insert = new javax.swing.JButton();
        btn_Update = new javax.swing.JButton();
        btn_Delete = new javax.swing.JButton();
        jLabel24 = new javax.swing.JLabel();

        jLabel1.setFont(new java.awt.Font("Calibri", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 0, 0));
        jLabel1.setText("Manage Payment");

        jLabel3.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(0, 0, 0));
        jLabel3.setText("Payment Id");

        txt_Payment_Id.setBackground(new java.awt.Color(255, 255, 255));

        jLabel9.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(0, 0, 0));
        jLabel9.setText("Item  Issued Date");

        cmbItemType.setBackground(new java.awt.Color(255, 255, 255));
        cmbItemType.setLayout(null);

        jLabel13.setFont(new java.awt.Font("Calibri", 1, 24)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(0, 0, 0));
        jLabel13.setText("Manage Payment");
        cmbItemType.add(jLabel13);
        jLabel13.setBounds(220, 20, 220, 60);

        jLabel14.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(0, 0, 0));
        jLabel14.setText("Payment Id");
        cmbItemType.add(jLabel14);
        jLabel14.setBounds(80, 90, 80, 20);

        txt_Payment_Id6.setBackground(new java.awt.Color(255, 255, 255));
        cmbItemType.add(txt_Payment_Id6);
        txt_Payment_Id6.setBounds(80, 120, 120, 28);

        jLabel15.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(0, 0, 0));
        jLabel15.setText("Customer Id");
        cmbItemType.add(jLabel15);
        jLabel15.setBounds(80, 160, 80, 20);

        jLabel16.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        jLabel16.setForeground(new java.awt.Color(0, 0, 0));
        jLabel16.setText("Customer Name");
        cmbItemType.add(jLabel16);
        jLabel16.setBounds(80, 220, 100, 20);

        txt_Customer_Name.setBackground(new java.awt.Color(255, 255, 255));
        cmbItemType.add(txt_Customer_Name);
        txt_Customer_Name.setBounds(80, 240, 120, 28);

        jLabel17.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        jLabel17.setForeground(new java.awt.Color(0, 0, 0));
        jLabel17.setText("Item Id");
        cmbItemType.add(jLabel17);
        jLabel17.setBounds(80, 340, 80, 20);

        jLabel18.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        jLabel18.setForeground(new java.awt.Color(0, 0, 0));
        jLabel18.setText("Date ");
        cmbItemType.add(jLabel18);
        jLabel18.setBounds(80, 280, 80, 20);

        jLabel19.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        jLabel19.setForeground(new java.awt.Color(0, 0, 0));
        jLabel19.setText("Item Name");
        cmbItemType.add(jLabel19);
        jLabel19.setBounds(280, 150, 80, 20);

        jLabel20.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        jLabel20.setForeground(new java.awt.Color(0, 0, 0));
        jLabel20.setText("Unit Price");
        cmbItemType.add(jLabel20);
        jLabel20.setBounds(280, 260, 80, 20);

        txt_Unit_Price.setBackground(new java.awt.Color(255, 255, 255));
        cmbItemType.add(txt_Unit_Price);
        txt_Unit_Price.setBounds(280, 290, 120, 28);

        jLabel21.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        jLabel21.setForeground(new java.awt.Color(0, 0, 0));
        jLabel21.setText("Total Amount");
        cmbItemType.add(jLabel21);
        jLabel21.setBounds(280, 330, 80, 20);

        txt_Total_Amount.setBackground(new java.awt.Color(255, 255, 255));
        cmbItemType.add(txt_Total_Amount);
        txt_Total_Amount.setBounds(280, 360, 120, 28);

        btn_Add_Payment.setBackground(new java.awt.Color(0, 153, 255));
        btn_Add_Payment.setForeground(new java.awt.Color(0, 0, 0));
        btn_Add_Payment.setText("Add ");
        btn_Add_Payment.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_Add_PaymentActionPerformed(evt);
            }
        });
        cmbItemType.add(btn_Add_Payment);
        btn_Add_Payment.setBounds(500, 130, 73, 28);

        btn_Update_Payment.setBackground(new java.awt.Color(255, 153, 0));
        btn_Update_Payment.setForeground(new java.awt.Color(0, 0, 0));
        btn_Update_Payment.setText("Update");
        btn_Update_Payment.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_Update_PaymentActionPerformed(evt);
            }
        });
        cmbItemType.add(btn_Update_Payment);
        btn_Update_Payment.setBounds(500, 180, 73, 28);

        btn_Clear.setBackground(new java.awt.Color(204, 204, 204));
        btn_Clear.setForeground(new java.awt.Color(0, 0, 0));
        btn_Clear.setText("Clear");
        btn_Clear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_ClearActionPerformed(evt);
            }
        });
        cmbItemType.add(btn_Clear);
        btn_Clear.setBounds(500, 280, 73, 28);

        btn_Delete_Payment.setBackground(new java.awt.Color(255, 51, 0));
        btn_Delete_Payment.setForeground(new java.awt.Color(0, 0, 0));
        btn_Delete_Payment.setText("Delete");
        cmbItemType.add(btn_Delete_Payment);
        btn_Delete_Payment.setBounds(500, 230, 73, 28);

        dtp_PaymentDate.setBackground(new java.awt.Color(255, 255, 255));
        cmbItemType.add(dtp_PaymentDate);
        dtp_PaymentDate.setBounds(80, 310, 160, 28);

        cmb_Item_Id.setBackground(new java.awt.Color(255, 255, 255));
        cmb_Item_Id.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "I1", "I2", "I3", " " }));
        cmbItemType.add(cmb_Item_Id);
        cmb_Item_Id.setBounds(80, 360, 120, 26);

        jLabel22.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        jLabel22.setForeground(new java.awt.Color(0, 0, 0));
        jLabel22.setText("Item Type");
        cmbItemType.add(jLabel22);
        jLabel22.setBounds(280, 90, 80, 20);

        txt_Item_Name.setBackground(new java.awt.Color(255, 255, 255));
        cmbItemType.add(txt_Item_Name);
        txt_Item_Name.setBounds(280, 170, 120, 28);

        cmb_Item_Type.setBackground(new java.awt.Color(255, 255, 255));
        cmb_Item_Type.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Beverages", "Food", "Other", " ", " " }));
        cmb_Item_Type.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmb_Item_TypeActionPerformed(evt);
            }
        });
        cmbItemType.add(cmb_Item_Type);
        cmb_Item_Type.setBounds(280, 120, 120, 26);

        jLabel23.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        jLabel23.setForeground(new java.awt.Color(0, 0, 0));
        jLabel23.setText("Quantity");
        cmbItemType.add(jLabel23);
        jLabel23.setBounds(280, 200, 80, 20);

        txt_Quantity2.setBackground(new java.awt.Color(255, 255, 255));
        cmbItemType.add(txt_Quantity2);
        txt_Quantity2.setBounds(280, 220, 120, 28);

        cmb_Customer_Type.setBackground(new java.awt.Color(255, 255, 255));
        cmb_Customer_Type.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "C1", "C2", "C3" }));
        cmb_Customer_Type.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmb_Customer_TypeActionPerformed(evt);
            }
        });
        cmbItemType.add(cmb_Customer_Type);
        cmb_Customer_Type.setBounds(80, 180, 120, 26);

        jButton4.setBackground(new java.awt.Color(255, 0, 0));
        jButton4.setText("Delete");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setPreferredSize(new java.awt.Dimension(500, 425));
        getContentPane().setLayout(null);

        jPanel1.setBackground(new java.awt.Color(51, 255, 102));
        jPanel1.setLayout(null);

        jLabel2.setFont(new java.awt.Font("Calibri", 1, 24)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 0, 0));
        jLabel2.setText("Manage Item");
        jPanel1.add(jLabel2);
        jLabel2.setBounds(180, 40, 220, 60);

        getContentPane().add(jPanel1);
        jPanel1.setBounds(-3, -27, 510, 100);

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setLayout(null);

        jLabel4.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(0, 0, 0));
        jLabel4.setText("Description");
        jPanel2.add(jLabel4);
        jLabel4.setBounds(230, 180, 110, 20);

        txt_Quantity.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.add(txt_Quantity);
        txt_Quantity.setBounds(230, 70, 120, 28);

        jLabel5.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(0, 0, 0));
        jLabel5.setText("Item Id");
        jPanel2.add(jLabel5);
        jLabel5.setBounds(40, 40, 80, 20);

        txt_Item_Id.setBackground(new java.awt.Color(255, 255, 255));
        txt_Item_Id.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txt_Item_IdKeyReleased(evt);
            }
        });
        jPanel2.add(txt_Item_Id);
        txt_Item_Id.setBounds(40, 70, 120, 28);

        cmb_Type.setBackground(new java.awt.Color(255, 255, 255));
        cmb_Type.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Beverages", "Juices", "Foods", " " }));
        jPanel2.add(cmb_Type);
        cmb_Type.setBounds(40, 210, 120, 26);

        jLabel8.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(0, 0, 0));
        jLabel8.setText("Item Type");
        jPanel2.add(jLabel8);
        jLabel8.setBounds(40, 180, 80, 20);

        dtp_Issued_Date.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.add(dtp_Issued_Date);
        dtp_Issued_Date.setBounds(40, 280, 120, 28);

        jLabel10.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(0, 0, 0));
        jLabel10.setText("Item  Issued Date");
        jPanel2.add(jLabel10);
        jLabel10.setBounds(40, 250, 110, 20);

        txt_Description.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.add(txt_Description);
        txt_Description.setBounds(230, 210, 120, 30);

        jLabel11.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(0, 0, 0));
        jLabel11.setText("Item Quanity");
        jPanel2.add(jLabel11);
        jLabel11.setBounds(230, 40, 110, 20);

        txt_Item_name.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.add(txt_Item_name);
        txt_Item_name.setBounds(40, 140, 120, 28);

        jLabel12.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(0, 0, 0));
        jLabel12.setText("Unit Price");
        jPanel2.add(jLabel12);
        jLabel12.setBounds(230, 110, 110, 20);

        txt_Unitprice.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.add(txt_Unitprice);
        txt_Unitprice.setBounds(230, 140, 120, 28);

        btn_Reset.setBackground(new java.awt.Color(153, 153, 153));
        btn_Reset.setText("Clear");
        btn_Reset.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_ResetActionPerformed(evt);
            }
        });
        jPanel2.add(btn_Reset);
        btn_Reset.setBounds(410, 270, 73, 28);

        btn_Insert.setBackground(new java.awt.Color(0, 204, 255));
        btn_Insert.setText("Insert");
        btn_Insert.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_InsertActionPerformed(evt);
            }
        });
        jPanel2.add(btn_Insert);
        btn_Insert.setBounds(410, 100, 73, 28);

        btn_Update.setBackground(new java.awt.Color(255, 153, 0));
        btn_Update.setText("Update");
        btn_Update.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_UpdateActionPerformed(evt);
            }
        });
        jPanel2.add(btn_Update);
        btn_Update.setBounds(410, 160, 73, 28);

        btn_Delete.setBackground(new java.awt.Color(255, 0, 0));
        btn_Delete.setText("Delete");
        btn_Delete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_DeleteActionPerformed(evt);
            }
        });
        jPanel2.add(btn_Delete);
        btn_Delete.setBounds(410, 220, 73, 28);

        jLabel24.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        jLabel24.setForeground(new java.awt.Color(0, 0, 0));
        jLabel24.setText("Item Name");
        jPanel2.add(jLabel24);
        jLabel24.setBounds(40, 110, 80, 20);

        getContentPane().add(jPanel2);
        jPanel2.setBounds(0, 70, 520, 330);

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    
    private void btn_Add_PaymentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_Add_PaymentActionPerformed
       /* String paymentId = txt_Payment_Id.getText();
        String customerId = cmb_Customer_Type.getSelectedItem().toString();
        String customerName = txt_Customer_Name.getText();
       // Date paymentDate = dtp_PaymentDate.getDate();
        String itemId = cmb_Item_Id.getSelectedItem().toString();
        String itemType = cmb_Item_Type.getSelectedItem().toString();
        String itemName = txt_Item_Name.getText();
        int Quantity = Integer.parseInt(txt_Quantity2.getText());
        double unitPrice = Double.parseDouble(txt_Unit_Price.getText());
        double totalAmount = Double.parseDouble(txt_Total_Amount.getText());
       // CPayment addPay = new CPayment();
      //  addPay.addPayment(paymentId, customerId, customerName, paymentDate, itemId, itemName, Quantity, unitPrice, totalAmount);
      */
    }//GEN-LAST:event_btn_Add_PaymentActionPerformed

    private void btn_Update_PaymentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_Update_PaymentActionPerformed
       /* String paymentId = txt_Payment_Id.getText();
        String customerId = cmb_Customer_Type.getSelectedItem().toString();
        String customerName = txt_Customer_Name.getText();
       // Date paymentDate = dtp_PaymentDate.getDate();
        String itemId = cmb_Item_Id.getSelectedItem().toString();
        String itemType = cmb_Item_Type.getSelectedItem().toString();
        String itemName = txt_Item_Name.getText();
        int Quantity = Integer.parseInt(txt_Quantity2.getText());
        double unitPrice = Double.parseDouble(txt_Unit_Price.getText());
        double totalAmount = Double.parseDouble(txt_Total_Amount.getText());
      //  CPayment updatePay = new CPayment();
       // updatePay.updatePayment(paymentId, customerId, customerName, paymentDate, itemId, itemType, itemName, Quantity, unitPrice, totalAmount);
      */
    }//GEN-LAST:event_btn_Update_PaymentActionPerformed

    private void btn_ClearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_ClearActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btn_ClearActionPerformed

    private void cmb_Item_TypeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmb_Item_TypeActionPerformed
       // String selectedItemId = (String) cmb_Item_Type.getSelectedItem();
       // JTextField[] fields = {txt_Customer_Name};

        //model.displayItemDetail(selectedItemId, fields);
    }//GEN-LAST:event_cmb_Item_TypeActionPerformed

    private void cmb_Customer_TypeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmb_Customer_TypeActionPerformed

      //  String selectedCustomerId = (String) cmb_Customer_Type.getSelectedItem();
       // JTextField[] fields = {txt_Customer_Name};

        //model.displayCustomerDetail(selectedCustomerId, fields);

    }//GEN-LAST:event_cmb_Customer_TypeActionPerformed

    private void btn_InsertActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_InsertActionPerformed
        
        JTextField[] fields = {txt_Item_name, txt_Quantity, txt_Unitprice, txt_Description};
        String itemId = txt_Item_Id.getText();
        String itemName = txt_Item_name.getText();
        String itemType = cmb_Item_Type.getSelectedItem().toString();
        Date issuedDate = dtp_Issued_Date.getDate();
        int Quantity = Integer.parseInt(txt_Quantity.getText());
        double unitprice = Double.parseDouble(txt_Unitprice.getText());
        String Description = txt_Description.getText();
        
        
         CItem addItemDetails = new CItem();
         addItemDetails.addItem(itemId, itemName, itemType, issuedDate, Quantity, unitprice, Description, fields, cmb_Type, dtp_Issued_Date);
                 
        
        

        
        
        
                
    }//GEN-LAST:event_btn_InsertActionPerformed

    private void txt_Item_IdKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_Item_IdKeyReleased
       
       String itemId = txt_Item_Id.getText();
        if (!itemId.isEmpty()) {
            MItem item = new MItem();
            JTextField[] fields = {txt_Item_name,txt_Quantity,txt_Unitprice,txt_Description};
            JComboBox[] comboBoxes = {cmb_Type};
            JDateChooser datepicker = dtp_Issued_Date;
            item.displayItem(itemId, fields, cmb_Type, datepicker);
        }   
    }//GEN-LAST:event_txt_Item_IdKeyReleased

    private void btn_UpdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_UpdateActionPerformed
       
        String itemId = txt_Item_Id.getText();
        String itemName = txt_Item_name.getText();
        String itemType = cmb_Item_Type.getSelectedItem().toString();
        Date issuedDate = dtp_Issued_Date.getDate();
        int Quantity = Integer.parseInt(txt_Quantity.getText());
        double unitprice = Double.parseDouble(txt_Unitprice.getText());
        String Description = txt_Description.getText();
        
        CItem updateItemdetails = new CItem();
        updateItemdetails.updateItem(itemId, itemName, itemType, issuedDate, Quantity, unitprice, Description, cmb_Type);
                
        
        
    }//GEN-LAST:event_btn_UpdateActionPerformed

    private void btn_DeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_DeleteActionPerformed
       
         String itemId = txt_Item_Id.getText();
         CItem deleteItemDetail = new CItem();
         deleteItemDetail.deleteItem(itemId);
                 
        
    }//GEN-LAST:event_btn_DeleteActionPerformed

    private void btn_ResetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_ResetActionPerformed
        
        txt_Item_Id.setText("");
        txt_Item_name.setText("");
        cmb_Item_Type.setSelectedIndex(0); // or cmb_Item_Type.setSelectedItem(null) if you want to deselect all items
        dtp_Issued_Date.setDate(null);
        txt_Quantity.setText("");
        txt_Unitprice.setText("");
        txt_Description.setText("");
        
    }//GEN-LAST:event_btn_ResetActionPerformed


   
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Manage_Item.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Manage_Item.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Manage_Item.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Manage_Item.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Manage_Item().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_Add_Payment;
    private javax.swing.JButton btn_Clear;
    private javax.swing.JButton btn_Delete;
    private javax.swing.JButton btn_Delete_Payment;
    private javax.swing.JButton btn_Insert;
    private javax.swing.JButton btn_Reset;
    private javax.swing.JButton btn_Update;
    private javax.swing.JButton btn_Update_Payment;
    private javax.swing.JPanel cmbItemType;
    private javax.swing.JComboBox<String> cmb_Customer_Type;
    private javax.swing.JComboBox<String> cmb_Item_Id;
    private javax.swing.JComboBox<String> cmb_Item_Type;
    private javax.swing.JComboBox<String> cmb_Type;
    private com.toedter.calendar.JDateChooser dtp_Issued_Date;
    private com.toedter.calendar.JDateChooser dtp_PaymentDate;
    private javax.swing.JButton jButton4;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JTextField txt_Customer_Name;
    private javax.swing.JTextField txt_Description;
    private javax.swing.JTextField txt_Item_Id;
    private javax.swing.JTextField txt_Item_Name;
    private javax.swing.JTextField txt_Item_name;
    private javax.swing.JTextField txt_Payment_Id;
    private javax.swing.JTextField txt_Payment_Id6;
    private javax.swing.JTextField txt_Quantity;
    private javax.swing.JTextField txt_Quantity2;
    private javax.swing.JTextField txt_Total_Amount;
    private javax.swing.JTextField txt_Unit_Price;
    private javax.swing.JTextField txt_Unitprice;
    // End of variables declaration//GEN-END:variables
}
