
package view;

import controller.CLogin;
import model.MLogin;
import javax.swing.JOptionPane;
import javax.swing.JCheckBox;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


public class Login extends javax.swing.JFrame {

    
    public Login() {
        initComponents();
    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        panel1 = new java.awt.Panel();
        jLabel12 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        panel2 = new java.awt.Panel();
        jLabel9 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        cmb_UserType = new javax.swing.JComboBox<>();
        txt_Username = new javax.swing.JTextField();
        btn_Clear = new javax.swing.JButton();
        sh_Password = new javax.swing.JCheckBox();
        jLabel4 = new javax.swing.JLabel();
        btm_Sign_Up = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        txt_Password = new javax.swing.JPasswordField();
        btm_Login1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setPreferredSize(new java.awt.Dimension(475, 430));
        getContentPane().setLayout(null);

        panel1.setBackground(new java.awt.Color(102, 255, 102));
        panel1.setLayout(null);
        panel1.add(jLabel12);
        jLabel12.setBounds(40, 70, 120, 110);

        jLabel2.setIcon(new javax.swing.ImageIcon("C:\\Users\\Defaulter\\Downloads\\2x\\Asset 3@2x.png")); // NOI18N
        panel1.add(jLabel2);
        jLabel2.setBounds(30, 50, 140, 70);

        getContentPane().add(panel1);
        panel1.setBounds(0, -10, 200, 410);

        panel2.setLayout(null);

        jLabel9.setFont(new java.awt.Font("Calibri", 1, 24)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(0, 0, 0));
        jLabel9.setText("Login");
        panel2.add(jLabel9);
        jLabel9.setBounds(110, 10, 120, 50);

        jLabel1.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 0, 0));
        jLabel1.setText("Password");
        panel2.add(jLabel1);
        jLabel1.setBounds(40, 200, 70, 20);

        jLabel3.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(0, 0, 0));
        jLabel3.setText("Username");
        panel2.add(jLabel3);
        jLabel3.setBounds(40, 140, 70, 20);

        cmb_UserType.setBackground(new java.awt.Color(255, 255, 255));
        cmb_UserType.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Sale", "Cashier", " " }));
        panel2.add(cmb_UserType);
        cmb_UserType.setBounds(40, 100, 80, 26);

        txt_Username.setBackground(new java.awt.Color(255, 255, 255));
        panel2.add(txt_Username);
        txt_Username.setBounds(40, 160, 190, 28);

        btn_Clear.setBackground(new java.awt.Color(153, 153, 153));
        btn_Clear.setForeground(new java.awt.Color(0, 0, 0));
        btn_Clear.setText("Clear");
        btn_Clear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_ClearActionPerformed(evt);
            }
        });
        panel2.add(btn_Clear);
        btn_Clear.setBounds(140, 290, 90, 28);

        sh_Password.setBackground(new java.awt.Color(0, 0, 0));
        sh_Password.setForeground(java.awt.Color.black);
        sh_Password.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sh_PasswordActionPerformed(evt);
            }
        });
        panel2.add(sh_Password);
        sh_Password.setBounds(210, 260, 20, 18);

        jLabel4.setFont(new java.awt.Font("Calibri", 0, 12)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(0, 0, 0));
        jLabel4.setText("Don't have an account?");
        panel2.add(jLabel4);
        jLabel4.setBounds(70, 330, 120, 30);

        btm_Sign_Up.setBackground(new java.awt.Color(51, 153, 255));
        btm_Sign_Up.setForeground(new java.awt.Color(0, 0, 0));
        btm_Sign_Up.setText("Sign Up");
        btm_Sign_Up.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btm_Sign_UpActionPerformed(evt);
            }
        });
        panel2.add(btm_Sign_Up);
        btm_Sign_Up.setBounds(80, 360, 90, 28);

        jLabel5.setFont(new java.awt.Font("Calibri", 0, 12)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(0, 0, 0));
        jLabel5.setText("Already have an account?");
        panel2.add(jLabel5);
        jLabel5.setBounds(80, 420, 140, 20);

        jLabel8.setFont(new java.awt.Font("Calibri", 0, 12)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(0, 0, 153));
        jLabel8.setText("Login");
        panel2.add(jLabel8);
        jLabel8.setBounds(210, 420, 50, 20);

        jLabel6.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(0, 0, 0));
        jLabel6.setText("User Type");
        panel2.add(jLabel6);
        jLabel6.setBounds(40, 70, 70, 20);

        txt_Password.setBackground(new java.awt.Color(255, 255, 255));
        panel2.add(txt_Password);
        txt_Password.setBounds(40, 220, 190, 28);

        btm_Login1.setBackground(new java.awt.Color(51, 153, 255));
        btm_Login1.setForeground(new java.awt.Color(0, 0, 0));
        btm_Login1.setText("Login");
        btm_Login1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btm_Login1ActionPerformed(evt);
            }
        });
        panel2.add(btm_Login1);
        btm_Login1.setBounds(40, 290, 90, 28);

        getContentPane().add(panel2);
        panel2.setBounds(200, 0, 290, 400);

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btm_Sign_UpActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btm_Sign_UpActionPerformed
       
       
        new SignUp().setVisible(true);

 
    }//GEN-LAST:event_btm_Sign_UpActionPerformed

    private void btm_Login1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btm_Login1ActionPerformed
        String userType, username, password;
        userType = cmb_UserType.getSelectedItem().toString();
        username = txt_Username.getText();
        password = new String(txt_Password.getPassword());

        CLogin login = new CLogin();
        MLogin.User user = login.login(userType, username, password);

    if (user != null) {
        JOptionPane.showMessageDialog(null, "You have successfully logged in to the System.", "Login Success", JOptionPane.INFORMATION_MESSAGE);
        // Redirect to the appropriate dashboard based on the user's role
        switch (userType) {
            case "Sale":
                SaleDashboard sale = new SaleDashboard();
                this.setVisible(false);
                sale.setVisible(true);
                return;
            case "Cashier":
                CashierDashboard cash = new CashierDashboard();
                this.setVisible(false);
                cash.setVisible(true);
                return;
            default:
                JOptionPane.showMessageDialog(null, "Invalid role.");
                break;
        }
        this.dispose(); // Close the login form
    } else {
        JOptionPane.showMessageDialog(null, "Invalid username, password, or role.", "Login Error", JOptionPane.ERROR_MESSAGE);
    }
   

  
    


  

 
   
    }//GEN-LAST:event_btm_Login1ActionPerformed

    private void sh_PasswordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sh_PasswordActionPerformed
        
        
         if (sh_Password.isSelected() == true) {
             txt_Password.setEchoChar((char) 0);
         }
         else
         {
             txt_Password.setEchoChar('*');
         }
                    
                
    }//GEN-LAST:event_sh_PasswordActionPerformed

    private void btn_ClearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_ClearActionPerformed
       
       
       txt_Username.setText("");
       txt_Password.setText("");
       
    }//GEN-LAST:event_btn_ClearActionPerformed

    
    
    
    
    
  
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Login().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btm_Login1;
    private javax.swing.JButton btm_Sign_Up;
    private javax.swing.JButton btn_Clear;
    private javax.swing.JComboBox<String> cmb_UserType;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private java.awt.Panel panel1;
    private java.awt.Panel panel2;
    private javax.swing.JCheckBox sh_Password;
    private javax.swing.JPasswordField txt_Password;
    private javax.swing.JTextField txt_Username;
    // End of variables declaration//GEN-END:variables
}
