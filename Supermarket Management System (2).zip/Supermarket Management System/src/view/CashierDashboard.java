
package view;


public class CashierDashboard extends javax.swing.JFrame {

    public CashierDashboard() {
        initComponents();
    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        btn_Payment = new javax.swing.JButton();
        btn_Add_Customer = new javax.swing.JButton();
        btn_Payment1 = new javax.swing.JButton();
        jMenuBar1 = new javax.swing.JMenuBar();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setPreferredSize(new java.awt.Dimension(430, 330));
        getContentPane().setLayout(null);

        jPanel1.setBackground(new java.awt.Color(102, 255, 102));
        jPanel1.setLayout(null);

        jLabel1.setFont(new java.awt.Font("Calibri", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 0, 0));
        jLabel1.setText("Cashier Dashboard");
        jPanel1.add(jLabel1);
        jLabel1.setBounds(100, 20, 220, 60);

        btn_Payment.setBackground(new java.awt.Color(255, 153, 0));
        btn_Payment.setForeground(new java.awt.Color(0, 0, 0));
        btn_Payment.setText("View Payment");
        btn_Payment.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_PaymentActionPerformed(evt);
            }
        });
        jPanel1.add(btn_Payment);
        btn_Payment.setBounds(140, 210, 150, 28);

        btn_Add_Customer.setBackground(new java.awt.Color(0, 153, 255));
        btn_Add_Customer.setForeground(new java.awt.Color(0, 0, 0));
        btn_Add_Customer.setText("Manage Customer");
        btn_Add_Customer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_Add_CustomerActionPerformed(evt);
            }
        });
        jPanel1.add(btn_Add_Customer);
        btn_Add_Customer.setBounds(140, 110, 150, 28);

        btn_Payment1.setBackground(new java.awt.Color(0, 153, 255));
        btn_Payment1.setForeground(new java.awt.Color(0, 0, 0));
        btn_Payment1.setText("Manage Payment");
        btn_Payment1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_Payment1ActionPerformed(evt);
            }
        });
        jPanel1.add(btn_Payment1);
        btn_Payment1.setBounds(140, 160, 150, 28);

        getContentPane().add(jPanel1);
        jPanel1.setBounds(0, -10, 430, 300);

        jMenuBar1.setBackground(new java.awt.Color(255, 255, 255));
        jMenuBar1.setForeground(new java.awt.Color(255, 255, 255));
        setJMenuBar(jMenuBar1);

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btn_Add_CustomerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_Add_CustomerActionPerformed
        
        new Manage_Customer().setVisible(true);
    }//GEN-LAST:event_btn_Add_CustomerActionPerformed

    private void btn_PaymentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_PaymentActionPerformed
        
        
        
    }//GEN-LAST:event_btn_PaymentActionPerformed

    private void btn_Payment1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_Payment1ActionPerformed
        
        new Payment().setVisible(true);
    }//GEN-LAST:event_btn_Payment1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(CashierDashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(CashierDashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(CashierDashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(CashierDashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new CashierDashboard().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_Add_Customer;
    private javax.swing.JButton btn_Payment;
    private javax.swing.JButton btn_Payment1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JPanel jPanel1;
    // End of variables declaration//GEN-END:variables
}
