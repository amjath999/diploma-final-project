
package view;
import controller.CSign_Up;

public class SignUp extends javax.swing.JFrame {

   
    public SignUp() {
        initComponents();
    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        panel1 = new java.awt.Panel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        panel2 = new java.awt.Panel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        txt_Email = new javax.swing.JTextField();
        cmb_Usertype = new javax.swing.JComboBox<>();
        jLabel5 = new javax.swing.JLabel();
        txt_Username = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        btn_Sign_Up = new javax.swing.JButton();
        lbl_Sign_Up = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        txt_Confirm_Password = new javax.swing.JPasswordField();
        txt_Password = new javax.swing.JPasswordField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setPreferredSize(new java.awt.Dimension(575, 488));
        getContentPane().setLayout(null);

        panel1.setBackground(new java.awt.Color(102, 255, 102));
        panel1.setLayout(null);

        jLabel10.setFont(new java.awt.Font("Calibri", 1, 24)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(0, 0, 0));
        jLabel10.setText("Management System");
        panel1.add(jLabel10);
        jLabel10.setBounds(10, 200, 210, 50);

        jLabel11.setFont(new java.awt.Font("Calibri", 1, 24)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(0, 0, 0));
        jLabel11.setText("Supermarket");
        panel1.add(jLabel11);
        jLabel11.setBounds(50, 160, 150, 50);

        getContentPane().add(panel1);
        panel1.setBounds(0, 0, 240, 450);

        panel2.setLayout(null);

        jLabel3.setFont(new java.awt.Font("Calibri", 0, 12)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(0, 0, 0));
        jLabel3.setText("Already have an account?");
        panel2.add(jLabel3);
        jLabel3.setBounds(80, 420, 140, 20);

        jLabel4.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(0, 0, 0));
        jLabel4.setText("Email");
        panel2.add(jLabel4);
        jLabel4.setBounds(40, 140, 80, 20);

        txt_Email.setBackground(new java.awt.Color(255, 255, 255));
        panel2.add(txt_Email);
        txt_Email.setBounds(40, 160, 240, 28);

        cmb_Usertype.setBackground(new java.awt.Color(255, 255, 255));
        cmb_Usertype.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Sale", "Cashier", "Storekeeper" }));
        panel2.add(cmb_Usertype);
        cmb_Usertype.setBounds(40, 100, 110, 26);

        jLabel5.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(0, 0, 0));
        jLabel5.setText("Username");
        jLabel5.setToolTipText("");
        panel2.add(jLabel5);
        jLabel5.setBounds(40, 200, 70, 20);

        txt_Username.setBackground(new java.awt.Color(255, 255, 255));
        panel2.add(txt_Username);
        txt_Username.setBounds(40, 220, 240, 28);

        jLabel6.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(0, 0, 0));
        jLabel6.setText("Password");
        panel2.add(jLabel6);
        jLabel6.setBounds(40, 260, 70, 20);

        jLabel1.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 0, 0));
        jLabel1.setText("Confirm Password");
        panel2.add(jLabel1);
        jLabel1.setBounds(40, 320, 110, 20);

        jLabel7.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(0, 0, 0));
        jLabel7.setText("User Type");
        panel2.add(jLabel7);
        jLabel7.setBounds(40, 80, 70, 20);

        btn_Sign_Up.setBackground(new java.awt.Color(0, 153, 255));
        btn_Sign_Up.setForeground(new java.awt.Color(0, 0, 0));
        btn_Sign_Up.setText("Sign Up");
        btn_Sign_Up.setToolTipText("");
        btn_Sign_Up.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_Sign_UpActionPerformed(evt);
            }
        });
        panel2.add(btn_Sign_Up);
        btn_Sign_Up.setBounds(40, 380, 240, 28);

        lbl_Sign_Up.setFont(new java.awt.Font("Calibri", 0, 12)); // NOI18N
        lbl_Sign_Up.setForeground(new java.awt.Color(0, 0, 153));
        lbl_Sign_Up.setText("Login");
        panel2.add(lbl_Sign_Up);
        lbl_Sign_Up.setBounds(210, 420, 50, 20);

        jLabel9.setFont(new java.awt.Font("Calibri", 1, 24)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(0, 0, 0));
        jLabel9.setText("Sign Up");
        panel2.add(jLabel9);
        jLabel9.setBounds(120, 20, 120, 50);

        txt_Confirm_Password.setBackground(new java.awt.Color(255, 255, 255));
        panel2.add(txt_Confirm_Password);
        txt_Confirm_Password.setBounds(40, 340, 240, 28);

        txt_Password.setBackground(new java.awt.Color(255, 255, 255));
        panel2.add(txt_Password);
        txt_Password.setBounds(40, 280, 240, 28);

        getContentPane().add(panel2);
        panel2.setBounds(240, 0, 310, 450);

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btn_Sign_UpActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_Sign_UpActionPerformed
        
        
        String userType,Email,username,password,confirm_password;
        userType = cmb_Usertype.getSelectedItem().toString();
        Email = txt_Email.getText();
        username = txt_Username.getText();
        password = new String(txt_Password.getPassword());
        confirm_password = new String(txt_Confirm_Password.getPassword());
        
        
        
        CSign_Up create = new CSign_Up();
        create.createAccount(userType, Email, username, password, confirm_password);
                
        
        
        
    }//GEN-LAST:event_btn_Sign_UpActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(SignUp.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(SignUp.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(SignUp.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(SignUp.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new SignUp().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_Sign_Up;
    private javax.swing.JComboBox<String> cmb_Usertype;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JLabel lbl_Sign_Up;
    private java.awt.Panel panel1;
    private java.awt.Panel panel2;
    private javax.swing.JPasswordField txt_Confirm_Password;
    private javax.swing.JTextField txt_Email;
    private javax.swing.JPasswordField txt_Password;
    private javax.swing.JTextField txt_Username;
    // End of variables declaration//GEN-END:variables
}
