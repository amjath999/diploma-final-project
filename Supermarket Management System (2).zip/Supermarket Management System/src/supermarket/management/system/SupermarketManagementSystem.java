
package supermarket.management.system;

import view.Login;


public class SupermarketManagementSystem {

   
    public static void main(String[] args){
            
            Login lg = new Login();
            lg.setVisible(true);
        
    }
    
}
